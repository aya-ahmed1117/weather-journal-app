
/* Global Variables */
 const localHosts = 'http://localhost:8800/';
const apiKey = "&appid=b12c9628efa8d4fe49400102837d0269&units=imperial";
const content = document.getElementById('content');//contentDiv
const dateN = document.getElementById('date');
const tempret = document.getElementById('temp');//tempDiv

const feelings = document.getElementById('feelings');
const zipAA = document.getElementById('zip');
 // if error
function getError(error){
    console.log('Check there is error: =>',error);
}

// Create a new date instance dynamically with JS
let d = new Date();
let newDate =d.getDate()+'/'+d.getMonth()+1+'/'+d.getFullYear();

// Event listener to add function to existing HTML DOM element
  document.getElementById('generate').addEventListener('click',ifGenerate);
  function ifGenerate() {
    const feelingsValue = document.getElementById('feelings').value;
    let zipCode = zipAA.value;
    let myUrl = `https://api.openweathermap.org/data/2.5/weather?zip=${zipCode}${apiKey}`;

    if(zipCode === ""){
    alert('please write ZIP');
    }

    getDemo(myUrl)
  .then((data) => {
    const feelings = document.getElementById('feelings').value;
  //console.log(feelings);
   // console.log(`Data = ${data}`);
    postData("/postData", {
      date: newDate,
      temp: data.main.temp,
      feelings: feelings,
    });
  })
  .then((data) => {
    //console.log(`Data2 = ${data}`);
    updateUI();
  });
} 



  // get feelings 
  const getDemo= async (url) =>{
    const response = await fetch(url);
try {
   const data =  await response.json();

   console.log(data);
   return data;

}catch(error){
  console.log("check error",error);}
}
  // post Data   
  const postData = async (url = "", data = {}) => {
    const response = await fetch(url, { 
      method: "POST",
      credentials: "same-origin",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });
  
    try {
      const newData = await response.json();
      console.log(newData);
  
      return newData;
    } catch (error) {
      console.log(error, "soooos");
    }
  };
  


  // update ui
  const updateUI = async () => {
    let zipCode = zipAA.value;
    const feelings2 = document.getElementById('feelings').value;

     const request = await fetch('/getAll');
     try {
         const allData = await request.json()
             //console.log(allData)
             dateN.innerHTML = '<img src="calendar.png" style="width:5%;"><strong>Date is:</strong>'+allData.date;
             tempret.innerHTML = '<img src="feedback.png" style="width:5%;"><strong>The degree</strong>:'+allData.temp;
             content.innerHTML = '<img src="thermometer.png" style="width:5%;"><strong>My feelings</strong>:'+allData.feelings;
             return allData;
             
          }catch(error){
     console.log(error,"help");
      }
  };

