// Require Express to run server and routes

const cors = require("cors");

const express = require("express");

const bodyParser = require("body-parser");

//const { request, response } = require('express');

//port

const port = 8800;

// Start up an instance of app

const app = express();

/* Middleware*/

//Here we are configuring express to use body-parser as middle-ware.

app.use(bodyParser.urlencoded({ extended: false }));

app.use(bodyParser.json());

// Cors for cross origin allowance

app.use(cors());

// Initialize the main project folder

app.use(express.static("website"));

// Setup Server

app.listen(port, () => {
  console.log(`Server Running On Port= http://localhost:${port}`);
});

//const feelingData = ;

// Setup empty JS object to act as endpoint for all routes

projectData = [];

app.get("/getAll",(request, response) =>{

//function getAll(request, response) {
  response.send(projectData);

  console.log(projectData);
});

app.post("/postData", (request, response) =>{

 //function postData(request, response) {
  newIntry = {
    date: request.body.date,

    temp: request.body.temp,

    feelings: request.body.feelings,
  };

  //projectData.push(newIntry);
  projectData = newIntry;

  console.log(projectData);

  response.send(projectData);
});